
function startTime() {
  const today = new Date();
  let h = today.getHours();
  let m = today.getMinutes();
  let s = today.getSeconds();
  m = checkTime(m);
  s = checkTime(s);
  document.getElementById('chart0').innerHTML =  h + ":" + m + ":" + s;
  setTimeout(startTime, 1000);
}

function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
}

startTime()

var ctx = document.getElementById('chart2').getContext('2d');
	var myPieChart = new Chart(ctx,{
	    type: 'pie',
	    data: {
	        labels: ["Babybell Cheese", "Chocolatebars", "Dutch liquorice","Peanutbutter"],
	        datasets: [{
	            label: "Passengers",
	            backgroundColor: [
	          	'rgb(139, 149, 201)',
	            'rgb(76, 59, 77)',
	            'rgb(97, 58, 58)' ,
	           	'rgb(82,183,159)' ,],
	            borderColor:  'rgb(54,57,59)',
	            data: [800, 1311, 1786,267],
	        }]
    	},
    	    // Configuration options go here
	    options: {
	    	plugins: { 
	    		legend: {
	    			labels: {
	    				color: "#838687",
	    			},
	    			position: 'bottom'
	    		},
	    	}
	    }	

});

var ctx  = document.getElementById('chart1').getContext('2d');
var chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',
    // The data for our dataset
    data: {
       labels: ["Monday", "Tuesday", "Wednesday", "Tuesday", "Friday", "Saturday", "Sunday"],
        datasets: [{
            label: "km traveled per day",
            backgroundColor: 'rgb(31,62,88)',
            borderColor: 'rgb(71, 137, 120)',
            data: [42.700, 41.980, 45.300, 42.711, 42.711, 43.067, 45.900],
        }]
    },

    // Configuration options go here
    options: {
    	plugins: {
    		legend: {
    			labels: {
    				color: "white",
    			}
    		}
    	}
    }
});

var ctx = document.getElementById('chart3').getContext('2d');
	var myBarChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	    	labels: ["Monday", "Tuesday", "Wednesday", "Tuesday", "Friday", "Saturday", "Sunday"],
	    	
	    	datasets: [{
	        	label: "Minus temperature outside",
	        	backgroundColor:'rgb(31,62,88)',
	        	borderColor:  'rgb(172, 215, 236)',
	        	data: [273, 266, 259, 264, 273, 269, 266],
	        }]
	},
});